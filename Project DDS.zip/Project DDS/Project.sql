
set serveroutput on;
set verify off;


CREATE OR REPLACE PACKAGE mypack AS

    PROCEDURE Regression(Res2 OUT Number);
 
   FUNCTION Make_Absolute(Res_catch In NUMBER) RETURN NUMBER;

END mypack;
/


CREATE OR REPLACE PACKAGE BODY mypack AS
	
	
			
	PROCEDURE Regression (Res2 OUT  NUMBER)
	IS
	
	
	
		
	alpha number;
	b1 number;
	b2 number;
	


	sum_Of_Y number;
	sum_Of_X1 number; --Ovrl
	sum_Of_X2 number; -- Age
	
	X1X1 number  ;
	X1X2 number;
	X2X2 number;
	X1Y  number;
	X2Y  number;
	
	--- to find Beta1,Beta2,Beta0
	
	sum_x1_squared number;  
	sum_x2_squared number;
	sum_x1y number;
	sum_x2y number;
	sum_x1x2 number;
	
	Res number;
	age_input NUMBER;
	overall_input NUMBER;

		
		
	
		BEGIN
		
			 -------------step 1(a)-------------
	
		select SUM (Market_Value ) into sum_Of_Y from Players;
		
        select SUM (Ovrl ) into sum_Of_X1 from Players;
		
		select SUM (Age) into sum_Of_X2 from Players;
		
		
		
		 -------------step 1(b)-------------
		
		X1X1 :=0;
		select Sum(Ovrl*Ovrl) into X1X1 from Players;
		--DBMS_OUTPUT.PUT_LINE(X1X1);
			
      
	    X1X2 :=0;
		select Sum(Ovrl*Age) into X1X2 from Players; 
		--DBMS_OUTPUT.PUT_LINE(X1X2);
		   
		   
		X2X2 :=0;
		select Sum(Age*Age) into X2X2 from Players; 
		--DBMS_OUTPUT.PUT_LINE(X2X2);
		
		
		X1Y :=0;
		select Sum(Ovrl*Market_Value) into X1Y from Players; 
		--DBMS_OUTPUT.PUT_LINE(X1Y);
			
		
 

		X2Y :=0;
		select Sum(Age*Market_Value) into X2Y from Players; 
		--DBMS_OUTPUT.PUT_LINE(X2Y);
		
		
		
		
		
		
		
		
		
		
		-------------------step2----------------------
		----------------------------------------------
		----------------------------------------------
		
		
		sum_x1_squared :=0;
		
		sum_x1_squared := X1X1-(sum_Of_X1*sum_Of_X1)/9;
		
		--DBMS_OUTPUT.PUT_LINE(sum_x1_squared);
		
		
		
		sum_x2_squared :=0;
		
		sum_x2_squared := X2X2-(sum_Of_X2*sum_Of_X2)/9;
		
		--DBMS_OUTPUT.PUT_LINE(sum_x2_squared);
		
		
		
		sum_x1y :=0;
		
		sum_x1y := X1Y-(sum_Of_X1*sum_Of_Y)/9;
		
		--DBMS_OUTPUT.PUT_LINE(sum_x1y);
		
		
		
		sum_x2y :=0;
		
		sum_x2y := X2Y-(sum_Of_X2*sum_Of_Y)/9;
		
		--DBMS_OUTPUT.PUT_LINE(sum_x2y);
		
		
		
		
		
		sum_x1x2 :=0;
		
		sum_x1x2 := X1X2-(sum_Of_X1*sum_Of_X2)/9;
		
		--DBMS_OUTPUT.PUT_LINE(sum_x1x2);
		
		
		
		
		------------ Calculate b1---------
		----------------------------------
		-----------------------------------
		
		
		b1:=0;
		b1:=((sum_x2_squared*sum_x1y)-(sum_x1x2*sum_x2y))/((sum_x1_squared*sum_x2_squared)-(sum_x1x2*sum_x1x2));
		--DBMS_OUTPUT.PUT_LINE(b1);
		
		b2:=0;
		b2:=((sum_x1_squared*sum_x2y)-(sum_x1x2*sum_x1y))/((sum_x1_squared*sum_x2_squared)-(sum_x1x2*sum_x1x2));
		--DBMS_OUTPUT.PUT_LINE(b2);
		
		
		alpha:=0;
		alpha:=(sum_of_Y/9)-((b1*sum_Of_X1)/9)-((b2*sum_Of_X2)/9);
		--DBMS_OUTPUT.PUT_LINE(alpha);
		
		
		
		-------------calculate result of regression from given value--------
		
		Res:=0;
		
		overall_input:=87;
		age_input:=28;
		
		
		Res:= alpha+b1*overall_input+b2*age_input;
		
	
		
		
		Res2:=Res;
	   
	
		End Regression;
		
		
		
	FUNCTION Make_Absolute(Res_catch In NUMBER) RETURN NUMBER
    IS	
		Final_out number:=0;
		pewpew number;
		
		 BEGIN 
		
			mypack.Regression(pewpew);
			Final_out:=pewpew;
			
			
				If Final_out < 0 then
		        Final_out:=Final_out*(-1);
		End if;
		
			
			 DBMS_OUTPUT.PUT_LINE(ROUND(Final_out,2));
		
		
		
		 return Final_out;

    END Make_Absolute;
		
		
END mypack;
/
	
	Declare
	
	Output_catch number;
	catch_function number;
	lolo number;

	
	
BEGIN
	
	    Output_catch:=0;
		mypack.Regression(Output_catch);
		
	
		catch_function:= mypack.Make_Absolute(lolo);
		
END;
/
commit;